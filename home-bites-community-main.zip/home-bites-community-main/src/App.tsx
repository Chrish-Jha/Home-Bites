import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { CartProvider } from "@/contexts/CartContext";

import Landing from "./pages/Landing";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import CustomerHome from "./pages/CustomerHome";
import SearchPage from "./pages/SearchPage";
import ChefProfile from "./pages/ChefProfile";
import CartPage from "./pages/CartPage";
import Checkout from "./pages/Checkout";
import OrderSuccess from "./pages/OrderSuccess";
import OrderTracking from "./pages/OrderTracking";
import OrderHistory from "./pages/OrderHistory";
import Profile from "./pages/Profile";
import DeliveryPortal from "./pages/DeliveryPortal";

import ChefOnboarding from "./pages/chef/ChefOnboarding";
import ChefDashboard from "./pages/chef/ChefDashboard";
import ChefMenu from "./pages/chef/ChefMenu";
import ChefOrders from "./pages/chef/ChefOrders";
import ChefReviews from "./pages/chef/ChefReviews";
import ChefEarnings from "./pages/chef/ChefEarnings";
import ChefSettings from "./pages/chef/ChefSettings";

import AdminDashboard from "./pages/admin/AdminDashboard";
import AdminApprovals from "./pages/admin/AdminApprovals";
import AdminUsers from "./pages/admin/AdminUsers";
import AdminOrders from "./pages/admin/AdminOrders";

import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <CartProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Public */}
            <Route path="/" element={<Landing />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />

            {/* Customer */}
            <Route path="/home" element={<CustomerHome />} />
            <Route path="/search" element={<SearchPage />} />
            <Route path="/chef/:id" element={<ChefProfile />} />
            <Route path="/cart" element={<CartPage />} />
            <Route path="/checkout" element={<Checkout />} />
            <Route path="/order-success" element={<OrderSuccess />} />
            <Route path="/order/:id" element={<OrderTracking />} />
            <Route path="/orders" element={<OrderHistory />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/delivery" element={<DeliveryPortal />} />

            {/* Chef */}
            <Route path="/chef/onboarding" element={<ChefOnboarding />} />
            <Route path="/chef/dashboard" element={<ChefDashboard />} />
            <Route path="/chef/menu" element={<ChefMenu />} />
            <Route path="/chef/orders" element={<ChefOrders />} />
            <Route path="/chef/reviews" element={<ChefReviews />} />
            <Route path="/chef/earnings" element={<ChefEarnings />} />
            <Route path="/chef/settings" element={<ChefSettings />} />

            {/* Admin */}
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/approvals" element={<AdminApprovals />} />
            <Route path="/admin/users" element={<AdminUsers />} />
            <Route path="/admin/orders" element={<AdminOrders />} />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </CartProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
