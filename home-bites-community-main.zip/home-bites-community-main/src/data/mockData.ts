export interface Chef {
  id: string;
  name: string;
  kitchenName: string;
  bio: string;
  city: string;
  rating: number;
  reviewCount: number;
  image: string;
  verified: boolean;
  speciality: string;
  deliveryRange: string;
  totalOrders: number;
  joinedDate: string;
  categories: string[];
}

export interface Dish {
  id: string;
  chefId: string;
  chefName: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isVeg: boolean;
  prepTime: string;
  rating: number;
  available: boolean;
}

export interface CartItem extends Dish {
  quantity: number;
}

export interface Order {
  id: string;
  customerId: string;
  customerName: string;
  chefId: string;
  chefName: string;
  items: { name: string; quantity: number; price: number }[];
  total: number;
  status: "placed" | "accepted" | "preparing" | "out_for_delivery" | "delivered";
  date: string;
  address: string;
  paymentMethod: string;
}

export interface Review {
  id: string;
  customerName: string;
  rating: number;
  comment: string;
  date: string;
  dishName: string;
}

export interface Address {
  id: string;
  label: string;
  full: string;
  isDefault: boolean;
}

export const categories = [
  { id: "south-indian", name: "South Indian", emoji: "🍛" },
  { id: "north-indian", name: "North Indian", emoji: "🫓" },
  { id: "snacks", name: "Snacks", emoji: "🥘" },
  { id: "biryani", name: "Biryani", emoji: "🍚" },
  { id: "desserts", name: "Desserts", emoji: "🍰" },
  { id: "thali", name: "Thali", emoji: "🍽️" },
  { id: "tiffin", name: "Tiffin", emoji: "🥡" },
  { id: "beverages", name: "Beverages", emoji: "🥤" },
];

export const chefs: Chef[] = [
  {
    id: "chef-1",
    name: "Lakshmi Devi",
    kitchenName: "Lakshmi's Kitchen",
    bio: "A passionate home cook with 15 years of experience. I believe every meal should be made with love and fresh ingredients from local markets.",
    city: "Hyderabad",
    rating: 4.8,
    reviewCount: 234,
    image: "https://images.unsplash.com/photo-1595273670150-bd0c3c392e46?w=200&h=200&fit=crop&crop=face",
    verified: true,
    speciality: "South Indian",
    deliveryRange: "5 km",
    totalOrders: 1250,
    joinedDate: "2023-06-15",
    categories: ["south-indian", "tiffin"],
  },
  {
    id: "chef-2",
    name: "Priya Sharma",
    kitchenName: "Priya's Home Food",
    bio: "Former software engineer turned home chef. I specialize in authentic North Indian flavors that remind you of your mother's cooking.",
    city: "Bangalore",
    rating: 4.9,
    reviewCount: 189,
    image: "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=200&h=200&fit=crop&crop=face",
    verified: true,
    speciality: "North Indian",
    deliveryRange: "7 km",
    totalOrders: 980,
    joinedDate: "2023-03-20",
    categories: ["north-indian", "thali"],
  },
  {
    id: "chef-3",
    name: "Fatima Begum",
    kitchenName: "Fatima's Biryani House",
    bio: "My biryani recipes have been passed down through 4 generations. Each grain of rice tells a story of tradition and love.",
    city: "Hyderabad",
    rating: 4.7,
    reviewCount: 312,
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=200&h=200&fit=crop&crop=face",
    verified: true,
    speciality: "Biryani",
    deliveryRange: "8 km",
    totalOrders: 2100,
    joinedDate: "2022-11-10",
    categories: ["biryani", "snacks"],
  },
  {
    id: "chef-4",
    name: "Anita Menon",
    kitchenName: "Kerala Flavors",
    bio: "Bringing the taste of Kerala to your doorstep. From appam to fish curry, experience authentic Malabar cuisine.",
    city: "Kochi",
    rating: 4.6,
    reviewCount: 156,
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&crop=face",
    verified: true,
    speciality: "South Indian",
    deliveryRange: "6 km",
    totalOrders: 750,
    joinedDate: "2023-09-05",
    categories: ["south-indian", "beverages"],
  },
  {
    id: "chef-5",
    name: "Sunita Patel",
    kitchenName: "Gujarat Rasoi",
    bio: "Healthy, tasty, and pure vegetarian. My thalis are famous in the neighbourhood and now available at your doorstep!",
    city: "Ahmedabad",
    rating: 4.5,
    reviewCount: 98,
    image: "https://images.unsplash.com/photo-1607746882042-944635dfe10e?w=200&h=200&fit=crop&crop=face",
    verified: false,
    speciality: "Thali",
    deliveryRange: "4 km",
    totalOrders: 420,
    joinedDate: "2024-01-12",
    categories: ["thali", "desserts"],
  },
  {
    id: "chef-6",
    name: "Meera Reddy",
    kitchenName: "Meera's Snack Corner",
    bio: "Evening snacks and tea-time treats are my specialty. From samosas to pakoras, everything is made fresh to order.",
    city: "Chennai",
    rating: 4.4,
    reviewCount: 145,
    image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop&crop=face",
    verified: true,
    speciality: "Snacks",
    deliveryRange: "5 km",
    totalOrders: 890,
    joinedDate: "2023-07-22",
    categories: ["snacks", "beverages"],
  },
];

export const dishes: Dish[] = [
  {
    id: "dish-1", chefId: "chef-1", chefName: "Lakshmi Devi",
    name: "Hyderabadi Masala Dosa", description: "Crispy dosa filled with spicy potato masala, served with coconut chutney and sambar",
    price: 80, image: "https://images.unsplash.com/photo-1630383249896-424e482df921?w=400&h=300&fit=crop",
    category: "south-indian", isVeg: true, prepTime: "20 min", rating: 4.8, available: true,
  },
  {
    id: "dish-2", chefId: "chef-1", chefName: "Lakshmi Devi",
    name: "Idli Sambar Plate", description: "Soft steamed idlis with piping hot sambar and three varieties of chutney",
    price: 60, image: "https://images.unsplash.com/photo-1589301760014-d929f3979dbc?w=400&h=300&fit=crop",
    category: "south-indian", isVeg: true, prepTime: "15 min", rating: 4.7, available: true,
  },
  {
    id: "dish-3", chefId: "chef-2", chefName: "Priya Sharma",
    name: "Butter Chicken with Naan", description: "Tender chicken in rich tomato-butter gravy, served with fresh tandoori naan",
    price: 220, image: "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=400&h=300&fit=crop",
    category: "north-indian", isVeg: false, prepTime: "35 min", rating: 4.9, available: true,
  },
  {
    id: "dish-4", chefId: "chef-2", chefName: "Priya Sharma",
    name: "Paneer Tikka Masala", description: "Grilled paneer cubes in smoky, spiced tomato gravy with aromatic spices",
    price: 180, image: "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=400&h=300&fit=crop",
    category: "north-indian", isVeg: true, prepTime: "30 min", rating: 4.8, available: true,
  },
  {
    id: "dish-5", chefId: "chef-3", chefName: "Fatima Begum",
    name: "Hyderabadi Chicken Biryani", description: "Slow-cooked dum biryani with tender chicken, aromatic basmati rice, and secret family spices",
    price: 250, image: "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400&h=300&fit=crop",
    category: "biryani", isVeg: false, prepTime: "45 min", rating: 4.9, available: true,
  },
  {
    id: "dish-6", chefId: "chef-3", chefName: "Fatima Begum",
    name: "Veg Biryani", description: "Fragrant vegetable biryani with garden-fresh vegetables and aromatic spices",
    price: 180, image: "https://images.unsplash.com/photo-1645177628172-a94c1f96e6db?w=400&h=300&fit=crop",
    category: "biryani", isVeg: true, prepTime: "40 min", rating: 4.6, available: true,
  },
  {
    id: "dish-7", chefId: "chef-4", chefName: "Anita Menon",
    name: "Kerala Fish Curry", description: "Traditional Malabar fish curry cooked in coconut milk with raw mango and spices",
    price: 200, image: "https://images.unsplash.com/photo-1626500155537-99dabc6b84f6?w=400&h=300&fit=crop",
    category: "south-indian", isVeg: false, prepTime: "35 min", rating: 4.7, available: true,
  },
  {
    id: "dish-8", chefId: "chef-5", chefName: "Sunita Patel",
    name: "Gujarati Thali", description: "Complete thali with dal, sabzi, roti, rice, pickle, papad, and sweet dish",
    price: 150, image: "https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&h=300&fit=crop",
    category: "thali", isVeg: true, prepTime: "25 min", rating: 4.5, available: true,
  },
  {
    id: "dish-9", chefId: "chef-6", chefName: "Meera Reddy",
    name: "Samosa Plate (4 pcs)", description: "Crispy golden samosas with spicy potato-pea filling, served with mint and tamarind chutney",
    price: 60, image: "https://images.unsplash.com/photo-1601050690117-94f5f6fa8bd7?w=400&h=300&fit=crop",
    category: "snacks", isVeg: true, prepTime: "15 min", rating: 4.4, available: true,
  },
  {
    id: "dish-10", chefId: "chef-6", chefName: "Meera Reddy",
    name: "Masala Chai & Pakora Combo", description: "Hot masala chai with crispy mixed vegetable pakoras — perfect evening snack",
    price: 70, image: "https://images.unsplash.com/photo-1571934811356-5cc061b6821f?w=400&h=300&fit=crop",
    category: "snacks", isVeg: true, prepTime: "10 min", rating: 4.3, available: true,
  },
  {
    id: "dish-11", chefId: "chef-1", chefName: "Lakshmi Devi",
    name: "Curd Rice", description: "Cooling curd rice tempered with mustard seeds, curry leaves, and fresh ginger",
    price: 50, image: "https://images.unsplash.com/photo-1585937421612-70a008356fbe?w=400&h=300&fit=crop",
    category: "south-indian", isVeg: true, prepTime: "10 min", rating: 4.6, available: true,
  },
  {
    id: "dish-12", chefId: "chef-2", chefName: "Priya Sharma",
    name: "Dal Makhani with Jeera Rice", description: "Creamy black lentils slow-cooked overnight, served with fragrant cumin rice",
    price: 160, image: "https://images.unsplash.com/photo-1596797038530-2c107229654b?w=400&h=300&fit=crop",
    category: "north-indian", isVeg: true, prepTime: "25 min", rating: 4.7, available: true,
  },
];

export const reviews: Review[] = [
  { id: "r1", customerName: "Amit K.", rating: 5, comment: "Best biryani I've ever had! Tastes just like my grandmother's cooking.", date: "2024-12-15", dishName: "Hyderabadi Chicken Biryani" },
  { id: "r2", customerName: "Sneha R.", rating: 4, comment: "Very tasty dosa. Chutney was amazing. Will order again!", date: "2024-12-14", dishName: "Hyderabadi Masala Dosa" },
  { id: "r3", customerName: "Rahul M.", rating: 5, comment: "The butter chicken was restaurant-level quality but with homemade love. Outstanding!", date: "2024-12-13", dishName: "Butter Chicken with Naan" },
  { id: "r4", customerName: "Pooja S.", rating: 4, comment: "Healthy and delicious thali. Perfect portion size and great variety.", date: "2024-12-12", dishName: "Gujarati Thali" },
  { id: "r5", customerName: "Vikram J.", rating: 5, comment: "Fresh, hot, and absolutely delicious. The samosas were crispy perfection!", date: "2024-12-11", dishName: "Samosa Plate" },
];

export const sampleOrders: Order[] = [
  {
    id: "ORD-001", customerId: "cust-1", customerName: "Amit Kumar", chefId: "chef-3", chefName: "Fatima Begum",
    items: [{ name: "Hyderabadi Chicken Biryani", quantity: 2, price: 250 }, { name: "Veg Biryani", quantity: 1, price: 180 }],
    total: 680, status: "delivered", date: "2024-12-15", address: "Flat 301, Green Valley Apts, Banjara Hills", paymentMethod: "UPI",
  },
  {
    id: "ORD-002", customerId: "cust-1", customerName: "Amit Kumar", chefId: "chef-1", chefName: "Lakshmi Devi",
    items: [{ name: "Hyderabadi Masala Dosa", quantity: 3, price: 80 }],
    total: 240, status: "preparing", date: "2024-12-16", address: "Flat 301, Green Valley Apts, Banjara Hills", paymentMethod: "Cash",
  },
  {
    id: "ORD-003", customerId: "cust-2", customerName: "Sneha Rao", chefId: "chef-2", chefName: "Priya Sharma",
    items: [{ name: "Butter Chicken with Naan", quantity: 1, price: 220 }, { name: "Dal Makhani with Jeera Rice", quantity: 1, price: 160 }],
    total: 380, status: "out_for_delivery", date: "2024-12-16", address: "House 45, Koramangala 4th Block", paymentMethod: "UPI",
  },
  {
    id: "ORD-004", customerId: "cust-3", customerName: "Rahul Mehta", chefId: "chef-5", chefName: "Sunita Patel",
    items: [{ name: "Gujarati Thali", quantity: 2, price: 150 }],
    total: 300, status: "placed", date: "2024-12-16", address: "B-12, Satellite Road, Ahmedabad", paymentMethod: "Card",
  },
  {
    id: "ORD-005", customerId: "cust-4", customerName: "Pooja Singh", chefId: "chef-6", chefName: "Meera Reddy",
    items: [{ name: "Samosa Plate (4 pcs)", quantity: 2, price: 60 }, { name: "Masala Chai & Pakora Combo", quantity: 2, price: 70 }],
    total: 260, status: "accepted", date: "2024-12-16", address: "23, Anna Nagar, Chennai", paymentMethod: "UPI",
  },
];

export const savedAddresses: Address[] = [
  { id: "addr-1", label: "Home", full: "Flat 301, Green Valley Apartments, Banjara Hills, Hyderabad - 500034", isDefault: true },
  { id: "addr-2", label: "Work", full: "Floor 5, Tech Park One, HITEC City, Hyderabad - 500081", isDefault: false },
  { id: "addr-3", label: "Mom's Place", full: "House 12, Street 4, Jubilee Hills, Hyderabad - 500033", isDefault: false },
];

export const testimonials = [
  { name: "Kavitha S.", role: "Home Maker", quote: "Home Bites gave me the confidence to turn my passion for cooking into a livelihood. I now earn independently while working from home.", image: "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=100&h=100&fit=crop&crop=face" },
  { name: "Rajesh P.", role: "Customer", quote: "The food is always fresh, tasty, and affordable. It's like having a home-cooked meal even when you're away from home!", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face" },
  { name: "Deepa M.", role: "Home Maker", quote: "I started with just 5 orders a day. Now I serve 30+ families daily. Home Bites changed my life and gave me financial freedom.", image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&h=100&fit=crop&crop=face" },
];

export const impactStats = [
  { label: "Women Empowered", value: "500+", icon: "👩‍🍳" },
  { label: "Meals Served", value: "1,00,000+", icon: "🍽️" },
  { label: "Happy Customers", value: "25,000+", icon: "😊" },
  { label: "Cities Active", value: "12", icon: "🏙️" },
];

export const faqs = [
  { question: "How does Home Bites work?", answer: "Home Bites connects you with verified home makers in your neighbourhood. Simply browse their menus, place an order, and enjoy fresh home-cooked meals delivered to your doorstep." },
  { question: "Is the food safe and hygienic?", answer: "Absolutely! All our home makers go through a verification process. Kitchens are inspected, and we encourage FSSAI registration. We also collect regular customer feedback to maintain quality." },
  { question: "How can I become a Home Maker on the platform?", answer: "Simply sign up as a Home Maker, complete your profile with kitchen details, upload your menu, and start receiving orders once approved. We support you every step of the way!" },
  { question: "What areas do you deliver to?", answer: "We currently operate in 12 cities across India. Delivery range depends on the home maker's location, typically within 5-8 km radius." },
  { question: "How are payments handled?", answer: "We support UPI, credit/debit cards, and cash on delivery. Home makers receive their earnings weekly directly to their bank accounts." },
  { question: "Can I customise my order?", answer: "Yes! You can add special instructions while placing your order. Many home makers are happy to accommodate dietary preferences and customisations." },
];
