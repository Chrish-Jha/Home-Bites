import { Navbar } from "@/components/Navbar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

const users = [
  { id: "U001", name: "Amit Kumar", email: "amit@example.com", role: "customer", city: "Hyderabad", joined: "2024-01-15", orders: 23 },
  { id: "U002", name: "Sneha Rao", email: "sneha@example.com", role: "customer", city: "Bangalore", joined: "2024-02-20", orders: 15 },
  { id: "U003", name: "Lakshmi Devi", email: "lakshmi@example.com", role: "chef", city: "Hyderabad", joined: "2023-06-15", orders: 1250 },
  { id: "U004", name: "Priya Sharma", email: "priya@example.com", role: "chef", city: "Bangalore", joined: "2023-03-20", orders: 980 },
  { id: "U005", name: "Rahul Mehta", email: "rahul@example.com", role: "customer", city: "Ahmedabad", joined: "2024-05-10", orders: 8 },
  { id: "U006", name: "Fatima Begum", email: "fatima@example.com", role: "chef", city: "Hyderabad", joined: "2022-11-10", orders: 2100 },
];

const AdminUsers = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="font-heading text-2xl font-bold">Users Management</h1>
        <div className="relative w-64">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search users..." className="pl-9" />
        </div>
      </div>

      <div className="rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Role</TableHead>
              <TableHead>City</TableHead>
              <TableHead>Orders</TableHead>
              <TableHead>Joined</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.id}>
                <TableCell className="font-mono text-sm">{user.id}</TableCell>
                <TableCell className="font-medium">{user.name}</TableCell>
                <TableCell className="text-muted-foreground">{user.email}</TableCell>
                <TableCell>
                  <Badge variant={user.role === "chef" ? "default" : "secondary"}>{user.role}</Badge>
                </TableCell>
                <TableCell>{user.city}</TableCell>
                <TableCell>{user.orders}</TableCell>
                <TableCell className="text-muted-foreground">{user.joined}</TableCell>
                <TableCell><Button variant="ghost" size="sm">View</Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  </div>
);

export default AdminUsers;
