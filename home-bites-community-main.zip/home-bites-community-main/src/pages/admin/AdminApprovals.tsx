import { Navbar } from "@/components/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { chefs } from "@/data/mockData";
import { CheckCircle2, XCircle, MapPin } from "lucide-react";

const pendingChefs = [
  { ...chefs[4], status: "pending" },
  { id: "chef-new-1", name: "Rekha Gupta", kitchenName: "Rekha's Rasoi", city: "Delhi", speciality: "North Indian", bio: "Passionate about making traditional recipes with a modern twist.", image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=200&h=200&fit=crop&crop=face", verified: false, rating: 0, reviewCount: 0, deliveryRange: "6 km", totalOrders: 0, joinedDate: "2024-12-10", categories: ["north-indian"] },
  { id: "chef-new-2", name: "Meenakshi R.", kitchenName: "Amma's Tiffin", city: "Chennai", speciality: "South Indian", bio: "Retired teacher who loves cooking for the community.", image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&h=200&fit=crop&crop=face", verified: false, rating: 0, reviewCount: 0, deliveryRange: "4 km", totalOrders: 0, joinedDate: "2024-12-12", categories: ["south-indian", "tiffin"] },
];

const AdminApprovals = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-6 font-heading text-2xl font-bold">Homemaker Approvals</h1>
      <p className="mb-6 text-muted-foreground">{pendingChefs.length} pending applications</p>

      <div className="space-y-4">
        {pendingChefs.map((chef) => (
          <Card key={chef.id}>
            <CardContent className="flex flex-col gap-4 p-6 md:flex-row">
              <img src={chef.image} alt={chef.name} className="h-20 w-20 rounded-full object-cover" />
              <div className="flex-1">
                <h3 className="mb-1 font-heading text-lg font-semibold">{chef.kitchenName}</h3>
                <p className="text-sm text-muted-foreground">{chef.name}</p>
                <p className="mb-2 text-sm text-muted-foreground">{chef.bio}</p>
                <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1"><MapPin size={14} /> {chef.city}</span>
                  <span>Speciality: {chef.speciality}</span>
                  <span>Delivery: {chef.deliveryRange}</span>
                  <span>Applied: {chef.joinedDate}</span>
                </div>
              </div>
              <div className="flex gap-2 self-start">
                <Button variant="outline" size="sm" className="gap-1 text-destructive"><XCircle size={16} /> Reject</Button>
                <Button size="sm" className="gap-1"><CheckCircle2 size={16} /> Approve</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  </div>
);

export default AdminApprovals;
