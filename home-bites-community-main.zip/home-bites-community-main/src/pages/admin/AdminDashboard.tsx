import { Navbar } from "@/components/Navbar";
import { DashboardCard } from "@/components/DashboardCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, ChefHat, ShoppingBag, Clock, DollarSign } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

const orderData = [
  { name: "Mon", orders: 45 }, { name: "Tue", orders: 52 }, { name: "Wed", orders: 48 },
  { name: "Thu", orders: 61 }, { name: "Fri", orders: 55 }, { name: "Sat", orders: 78 }, { name: "Sun", orders: 82 },
];

const revenueData = [
  { name: "Week 1", revenue: 12400 }, { name: "Week 2", revenue: 15600 }, { name: "Week 3", revenue: 14200 }, { name: "Week 4", revenue: 18900 },
];

const AdminDashboard = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-8 font-heading text-2xl font-bold">Admin Dashboard</h1>

      <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <DashboardCard title="Total Users" value="25,430" icon={Users} trend="+5.2%" />
        <DashboardCard title="Home Makers" value="512" icon={ChefHat} trend="+12 this week" />
        <DashboardCard title="Total Orders" value="1,02,350" icon={ShoppingBag} />
        <DashboardCard title="Pending Approvals" value={8} icon={Clock} description="Need review" />
        <DashboardCard title="Revenue" value="₹45.2L" icon={DollarSign} trend="+18% MoM" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle className="font-heading">Orders This Week</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={orderData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="orders" fill="hsl(24, 80%, 52%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="font-heading">Revenue Trend</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="revenue" stroke="hsl(24, 80%, 52%)" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  </div>
);

export default AdminDashboard;
