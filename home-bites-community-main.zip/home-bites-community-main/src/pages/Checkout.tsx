import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useCart } from "@/contexts/CartContext";
import { savedAddresses } from "@/data/mockData";
import { Link } from "react-router-dom";
import { MapPin, CreditCard } from "lucide-react";

const Checkout = () => {
  const { items, totalPrice, clearCart } = useCart();
  const [selectedAddress, setSelectedAddress] = useState(savedAddresses[0].id);
  const [paymentMethod, setPaymentMethod] = useState("upi");

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="mb-6 font-heading text-2xl font-bold">Checkout</h1>
        <div className="grid gap-8 lg:grid-cols-3">
          <div className="space-y-6 lg:col-span-2">
            {/* Address */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-heading"><MapPin size={18} /> Delivery Address</CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup value={selectedAddress} onValueChange={setSelectedAddress} className="space-y-3">
                  {savedAddresses.map((addr) => (
                    <div key={addr.id} className="flex items-start gap-3 rounded-lg border p-4">
                      <RadioGroupItem value={addr.id} id={addr.id} className="mt-1" />
                      <Label htmlFor={addr.id} className="cursor-pointer">
                        <span className="font-semibold">{addr.label}</span>
                        <p className="text-sm text-muted-foreground">{addr.full}</p>
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Payment */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-heading"><CreditCard size={18} /> Payment Method</CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-3">
                  {[
                    { id: "upi", label: "UPI / Google Pay", desc: "Pay instantly via UPI" },
                    { id: "card", label: "Credit / Debit Card", desc: "Visa, Mastercard, Rupay" },
                    { id: "cod", label: "Cash on Delivery", desc: "Pay when you receive" },
                  ].map((method) => (
                    <div key={method.id} className="flex items-start gap-3 rounded-lg border p-4">
                      <RadioGroupItem value={method.id} id={method.id} className="mt-1" />
                      <Label htmlFor={method.id} className="cursor-pointer">
                        <span className="font-semibold">{method.label}</span>
                        <p className="text-sm text-muted-foreground">{method.desc}</p>
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </CardContent>
            </Card>
          </div>

          {/* Summary */}
          <Card className="h-fit">
            <CardHeader>
              <CardTitle className="font-heading">Order Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {items.map((item) => (
                <div key={item.id} className="flex justify-between text-sm">
                  <span>{item.name} × {item.quantity}</span>
                  <span>₹{item.price * item.quantity}</span>
                </div>
              ))}
              <div className="border-t pt-2">
                <div className="flex justify-between text-sm"><span className="text-muted-foreground">Subtotal</span><span>₹{totalPrice}</span></div>
                <div className="flex justify-between text-sm"><span className="text-muted-foreground">Delivery</span><span>₹30</span></div>
                <div className="flex justify-between text-sm"><span className="text-muted-foreground">Platform Fee</span><span>₹5</span></div>
              </div>
              <div className="border-t pt-3">
                <div className="flex justify-between font-heading text-lg font-bold">
                  <span>Total</span><span>₹{totalPrice + 35}</span>
                </div>
              </div>
              <Link to="/order-success" onClick={() => clearCart()}>
                <Button className="w-full" size="lg">Place Order</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
