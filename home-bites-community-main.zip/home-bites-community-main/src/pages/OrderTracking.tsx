import { useParams } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { OrderStatusStepper } from "@/components/OrderStatusStepper";
import { sampleOrders } from "@/data/mockData";
import { MapPin, Phone, Clock } from "lucide-react";

const OrderTracking = () => {
  const { id } = useParams();
  const order = sampleOrders.find((o) => o.id === id) || sampleOrders[1];

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto max-w-2xl px-4 py-8">
        <h1 className="mb-2 font-heading text-2xl font-bold">Order #{order.id}</h1>
        <p className="mb-8 text-sm text-muted-foreground">Placed on {order.date}</p>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="font-heading">Order Status</CardTitle>
          </CardHeader>
          <CardContent>
            <OrderStatusStepper status={order.status} />
          </CardContent>
        </Card>

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="font-heading">Order Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm font-medium">From: {order.chefName}</p>
            {order.items.map((item, i) => (
              <div key={i} className="flex justify-between text-sm">
                <span>{item.name} × {item.quantity}</span>
                <span>₹{item.price * item.quantity}</span>
              </div>
            ))}
            <div className="border-t pt-3">
              <div className="flex justify-between font-heading font-bold">
                <span>Total</span><span>₹{order.total}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <MapPin size={18} className="mt-0.5 text-primary" />
              <div>
                <p className="text-sm font-medium">Delivery Address</p>
                <p className="text-sm text-muted-foreground">{order.address}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default OrderTracking;
