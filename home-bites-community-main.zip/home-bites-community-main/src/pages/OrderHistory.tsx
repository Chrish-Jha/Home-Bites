import { Navbar } from "@/components/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { sampleOrders } from "@/data/mockData";
import { Link } from "react-router-dom";

const statusColors: Record<string, string> = {
  placed: "bg-accent text-accent-foreground",
  accepted: "bg-primary/20 text-primary",
  preparing: "bg-primary/40 text-primary-foreground",
  out_for_delivery: "bg-primary text-primary-foreground",
  delivered: "bg-success text-success-foreground",
};

const OrderHistory = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-6 font-heading text-2xl font-bold">Order History</h1>
      <div className="space-y-4">
        {sampleOrders.map((order) => (
          <Card key={order.id}>
            <CardContent className="flex flex-col gap-4 p-4 md:flex-row md:items-center md:justify-between">
              <div>
                <div className="mb-1 flex items-center gap-3">
                  <span className="font-heading font-semibold">{order.id}</span>
                  <Badge className={statusColors[order.status]}>{order.status.replace("_", " ")}</Badge>
                </div>
                <p className="text-sm text-muted-foreground">{order.chefName} • {order.date}</p>
                <p className="text-sm text-muted-foreground">{order.items.map((i) => `${i.name} ×${i.quantity}`).join(", ")}</p>
              </div>
              <div className="flex items-center gap-4">
                <span className="font-heading text-lg font-bold">₹{order.total}</span>
                <Link to={`/order/${order.id}`}><Button variant="outline" size="sm">Track</Button></Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  </div>
);

export default OrderHistory;
