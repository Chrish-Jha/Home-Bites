import { Navbar } from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { savedAddresses } from "@/data/mockData";
import { User, MapPin, Phone, Mail, ShoppingBag } from "lucide-react";
import { Link } from "react-router-dom";

const Profile = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="container mx-auto max-w-2xl px-4 py-8">
      <h1 className="mb-6 font-heading text-2xl font-bold">My Profile</h1>

      <Card className="mb-6">
        <CardHeader><CardTitle className="font-heading">Personal Information</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2"><Label>Full Name</Label><Input defaultValue="Amit Kumar" /></div>
            <div className="space-y-2"><Label>Email</Label><Input defaultValue="amit@example.com" /></div>
            <div className="space-y-2"><Label>Phone</Label><Input defaultValue="+91 98765 43210" /></div>
            <div className="space-y-2"><Label>City</Label><Input defaultValue="Hyderabad" /></div>
          </div>
          <Button>Save Changes</Button>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="font-heading">Saved Addresses</CardTitle>
            <Button variant="outline" size="sm">Add New</Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          {savedAddresses.map((addr) => (
            <div key={addr.id} className="flex items-start justify-between rounded-lg border p-4">
              <div className="flex gap-3">
                <MapPin size={18} className="mt-0.5 text-primary" />
                <div>
                  <p className="font-semibold">{addr.label}</p>
                  <p className="text-sm text-muted-foreground">{addr.full}</p>
                </div>
              </div>
              <Button variant="ghost" size="sm">Edit</Button>
            </div>
          ))}
        </CardContent>
      </Card>

      <div className="flex gap-4">
        <Link to="/orders"><Button variant="outline" className="gap-2"><ShoppingBag size={16} /> Order History</Button></Link>
        <Link to="/login"><Button variant="ghost" className="text-destructive">Log Out</Button></Link>
      </div>
    </div>
  </div>
);

export default Profile;
