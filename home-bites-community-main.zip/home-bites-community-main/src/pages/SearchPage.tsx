import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { FoodCard } from "@/components/FoodCard";
import { CategoryChips } from "@/components/CategoryChips";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { dishes } from "@/data/mockData";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";

const SearchPage = () => {
  const [query, setQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [vegOnly, setVegOnly] = useState(false);
  const [maxPrice, setMaxPrice] = useState([500]);
  const [minRating, setMinRating] = useState([0]);

  const filtered = dishes.filter((d) => {
    const matchQ = d.name.toLowerCase().includes(query.toLowerCase()) || d.chefName.toLowerCase().includes(query.toLowerCase());
    const matchCat = selectedCategory === "all" || d.category === selectedCategory;
    const matchVeg = !vegOnly || d.isVeg;
    const matchPrice = d.price <= maxPrice[0];
    const matchRating = d.rating >= minRating[0];
    return matchQ && matchCat && matchVeg && matchPrice && matchRating;
  });

  const FilterControls = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <Label>Veg Only</Label>
        <Switch checked={vegOnly} onCheckedChange={setVegOnly} />
      </div>
      <div>
        <Label>Max Price: ₹{maxPrice[0]}</Label>
        <Slider value={maxPrice} onValueChange={setMaxPrice} min={20} max={500} step={10} className="mt-2" />
      </div>
      <div>
        <Label>Min Rating: {minRating[0]}⭐</Label>
        <Slider value={minRating} onValueChange={setMinRating} min={0} max={5} step={0.5} className="mt-2" />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-6">
        {/* Search Bar */}
        <div className="mb-6 flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
            <Input placeholder="Search dishes or home makers..." className="pl-10" value={query} onChange={(e) => setQuery(e.target.value)} />
          </div>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="shrink-0 md:hidden">
                <SlidersHorizontal size={18} />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <SheetHeader><SheetTitle>Filters</SheetTitle></SheetHeader>
              <div className="mt-6"><FilterControls /></div>
            </SheetContent>
          </Sheet>
        </div>

        <div className="mb-6">
          <CategoryChips selected={selectedCategory} onSelect={setSelectedCategory} />
        </div>

        <div className="flex gap-8">
          {/* Desktop Sidebar */}
          <aside className="hidden w-64 shrink-0 md:block">
            <div className="sticky top-24 rounded-lg border bg-card p-6">
              <h3 className="mb-4 font-heading font-semibold">Filters</h3>
              <FilterControls />
            </div>
          </aside>

          {/* Results */}
          <div className="flex-1">
            <p className="mb-4 text-sm text-muted-foreground">{filtered.length} dish{filtered.length !== 1 ? "es" : ""} found</p>
            {filtered.length === 0 ? (
              <div className="py-16 text-center text-muted-foreground">
                <p className="mb-4 text-4xl">🔍</p>
                <p>No dishes match your filters. Try adjusting your search.</p>
              </div>
            ) : (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {filtered.map((dish) => (
                  <FoodCard key={dish.id} dish={dish} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default SearchPage;
