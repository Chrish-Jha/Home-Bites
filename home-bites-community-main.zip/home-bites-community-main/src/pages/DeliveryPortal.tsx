import { Navbar } from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bike, Clock3, DollarSign, MapPinned, PackageCheck } from "lucide-react";

const deliveryStats = [
  { title: "Active Deliveries", value: "06", icon: Bike },
  { title: "Pending Pickups", value: "03", icon: PackageCheck },
  { title: "Avg. Delivery Time", value: "24 min", icon: Clock3 },
  { title: "Today's Earnings", value: "Rs.840", icon: DollarSign },
];

const tasks = [
  { orderId: "ORD-302", pickup: "Lakshmi's Kitchen", drop: "Madhapur", status: "Picked up" },
  { orderId: "ORD-303", pickup: "Amma's Tiffin", drop: "Gachibowli", status: "Ready for pickup" },
  { orderId: "ORD-304", pickup: "Priya Foods", drop: "Kondapur", status: "On the way" },
];

const DeliveryPortal = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold">Delivery Person Portal</h1>
          <p className="text-muted-foreground">Track pickups, route assignments, and delivery performance.</p>
        </div>
        <Button className="gap-2">
          <MapPinned size={16} />
          Update Live Location
        </Button>
      </div>

      <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {deliveryStats.map((item) => {
          const Icon = item.icon;
          return (
            <Card key={item.title}>
              <CardContent className="flex items-center justify-between p-6">
                <div>
                  <p className="text-sm text-muted-foreground">{item.title}</p>
                  <p className="mt-1 font-heading text-2xl font-bold">{item.value}</p>
                </div>
                <div className="rounded-xl bg-primary/10 p-3 text-primary">
                  <Icon className="h-5 w-5" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-heading">Assigned Tasks</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {tasks.map((task) => (
            <div key={task.orderId} className="rounded-lg border p-4">
              <div className="mb-2 flex items-center justify-between gap-4">
                <p className="font-semibold">{task.orderId}</p>
                <span className="rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                  {task.status}
                </span>
              </div>
              <p className="text-sm text-muted-foreground">Pickup: {task.pickup}</p>
              <p className="text-sm text-muted-foreground">Drop: {task.drop}</p>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  </div>
);

export default DeliveryPortal;
