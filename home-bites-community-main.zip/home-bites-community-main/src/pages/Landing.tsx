import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ChefCard } from "@/components/ChefCard";
import { FoodCard } from "@/components/FoodCard";
import { Footer } from "@/components/Footer";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { chefs, dishes, testimonials, impactStats, faqs } from "@/data/mockData";
import {
  ArrowRight,
  Bike,
  BriefcaseBusiness,
  Heart,
  ShieldCheck,
  ShoppingBag,
  Store,
  UserRound,
  Utensils,
} from "lucide-react";
import { motion } from "framer-motion";
import { BrandLogo } from "@/components/BrandLogo";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
};

const portals = [
  {
    title: "Customer",
    description: "Browse meals, place orders, track deliveries, and manage your account.",
    icon: UserRound,
    link: "/home",
    cta: "Open Customer Portal",
  },
  {
    title: "Supplier",
    description: "Manage your kitchen, add dishes, review orders, and track earnings.",
    icon: Store,
    link: "/chef/dashboard",
    cta: "Open Supplier Portal",
  },
  {
    title: "Delivery Person",
    description: "Check active pickups, delivery queue, route status, and earnings summary.",
    icon: Bike,
    link: "/delivery",
    cta: "Open Delivery Portal",
  },
  {
    title: "Company Person",
    description: "Access approvals, users, order oversight, and business-level reporting.",
    icon: BriefcaseBusiness,
    link: "/admin",
    cta: "Open Company Portal",
  },
];

const Landing = () => (
  <div className="min-h-screen">
    <nav className="sticky top-0 z-50 border-b bg-card/95 backdrop-blur">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2">
          <BrandLogo size="sm" />
        </Link>
        <div className="hidden items-center gap-6 md:flex">
          <a href="#portals" className="text-sm font-medium text-muted-foreground hover:text-foreground">Portals</a>
          <a href="#how-it-works" className="text-sm font-medium text-muted-foreground hover:text-foreground">How It Works</a>
          <a href="#chefs" className="text-sm font-medium text-muted-foreground hover:text-foreground">Home Makers</a>
          <a href="#impact" className="text-sm font-medium text-muted-foreground hover:text-foreground">Impact</a>
          <a href="#faq" className="text-sm font-medium text-muted-foreground hover:text-foreground">FAQ</a>
        </div>
        <div className="flex items-center gap-3">
          <Link to="/login"><Button variant="ghost" size="sm">Login</Button></Link>
          <Link to="/signup"><Button size="sm">Sign Up</Button></Link>
        </div>
      </div>
    </nav>

    <section className="relative overflow-hidden py-20 md:py-32">
      <div className="container mx-auto px-4">
        <motion.div className="mx-auto max-w-3xl text-center" initial="hidden" animate="visible" variants={fadeUp}>
          <span className="mb-4 inline-block rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            Empowering Women, One Meal at a Time
          </span>
          <h1 className="mb-6 font-heading text-4xl font-extrabold leading-tight md:text-6xl">
            Home-Cooked Meals,<br />
            <span className="text-primary">Made with Love</span>
          </h1>
          <p className="mb-8 text-lg text-muted-foreground md:text-xl">
            Order fresh, hygienic, and affordable meals from verified home makers in your neighbourhood. Every order supports a woman entrepreneur.
          </p>
          <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Link to="/home"><Button size="lg" className="gap-2 px-8 text-base">Browse Meals <ArrowRight size={18} /></Button></Link>
            <Link to="/chef/onboarding"><Button variant="outline" size="lg" className="gap-2 px-8 text-base">Become a Home Maker</Button></Link>
          </div>
        </motion.div>
      </div>
      <div className="absolute -bottom-20 left-0 right-0 h-40 bg-gradient-to-t from-background to-transparent" />
    </section>

    <section id="portals" className="bg-card py-20">
      <div className="container mx-auto px-4">
        <motion.div className="mx-auto mb-12 max-w-2xl text-center" initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
          <h2 className="mb-4 font-heading text-3xl font-bold md:text-4xl">Access Portals</h2>
          <p className="text-muted-foreground">
            Choose the workspace that matches your role in the Home Bites platform.
          </p>
        </motion.div>
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {portals.map((portal) => {
            const Icon = portal.icon;

            return (
              <motion.div key={portal.title} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
                <Card className="h-full border-primary/10 bg-background transition-shadow hover:shadow-lg">
                  <CardContent className="flex h-full flex-col p-6">
                    <div className="mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                      <Icon className="h-7 w-7" />
                    </div>
                    <h3 className="mb-2 font-heading text-xl font-semibold">{portal.title}</h3>
                    <p className="mb-6 flex-1 text-sm text-muted-foreground">{portal.description}</p>
                    <Link to={portal.link}>
                      <Button className="w-full gap-2">
                        {portal.cta}
                        <ArrowRight size={16} />
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>

    <section className="border-y bg-background py-8">
      <div className="container mx-auto flex flex-wrap items-center justify-center gap-8 px-4 text-sm text-muted-foreground">
        <span className="flex items-center gap-2"><ShieldCheck size={18} className="text-success" /> Verified Kitchens</span>
        <span className="flex items-center gap-2"><Heart size={18} className="text-primary" /> 100% Home-Cooked</span>
        <span className="flex items-center gap-2"><Utensils size={18} className="text-accent" /> Fresh & Hygienic</span>
        <span className="flex items-center gap-2"><ShoppingBag size={18} className="text-primary" /> Multi-role Platform</span>
      </div>
    </section>

    <section id="how-it-works" className="py-20">
      <div className="container mx-auto px-4">
        <motion.div className="mb-12 text-center" initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
          <h2 className="mb-4 font-heading text-3xl font-bold md:text-4xl">How It Works</h2>
          <p className="text-muted-foreground">Three simple steps to enjoy home-cooked food</p>
        </motion.div>
        <div className="grid gap-8 md:grid-cols-3">
          {[
            { step: "1", title: "Browse", desc: "Explore verified home makers and their delicious menus near you.", label: "Search" },
            { step: "2", title: "Order", desc: "Choose your favourite dishes, add to cart, and place your order.", label: "Cart" },
            { step: "3", title: "Enjoy", desc: "Get fresh, home-cooked meals delivered right to your doorstep.", label: "Meal" },
          ].map((item) => (
            <motion.div key={item.step} initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeUp}>
              <Card className="text-center">
                <CardContent className="p-8">
                  <span className="mb-4 inline-block text-2xl font-semibold text-primary">{item.label}</span>
                  <div className="mb-2 inline-flex h-8 w-8 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">{item.step}</div>
                  <h3 className="mb-2 font-heading text-xl font-semibold">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    <section id="chefs" className="bg-card py-20">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="mb-4 font-heading text-3xl font-bold md:text-4xl">Meet Our Home Makers</h2>
          <p className="text-muted-foreground">Passionate women creating delicious meals from their kitchens</p>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {chefs.slice(0, 6).map((chef) => (
            <ChefCard key={chef.id} chef={chef} />
          ))}
        </div>
        <div className="mt-8 text-center">
          <Link to="/home"><Button variant="outline" size="lg">View All Home Makers</Button></Link>
        </div>
      </div>
    </section>

    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="mb-4 font-heading text-3xl font-bold md:text-4xl">Popular Dishes</h2>
          <p className="text-muted-foreground">Loved by thousands of happy customers</p>
        </div>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {dishes.slice(0, 8).map((dish) => (
            <FoodCard key={dish.id} dish={dish} />
          ))}
        </div>
      </div>
    </section>

    <section id="impact" className="bg-primary py-20 text-primary-foreground">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="mb-4 font-heading text-3xl font-bold md:text-4xl">Our Impact</h2>
          <p className="opacity-90">Empowering women, nourishing communities</p>
        </div>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {impactStats.map((stat) => (
            <div key={stat.label} className="text-center">
              <span className="mb-2 block text-4xl">{stat.icon}</span>
              <p className="font-heading text-3xl font-bold">{stat.value}</p>
              <p className="mt-1 opacity-80">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>

    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="mb-12 text-center">
          <h2 className="mb-4 font-heading text-3xl font-bold md:text-4xl">What People Say</h2>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {testimonials.map((t) => (
            <Card key={t.name}>
              <CardContent className="p-6">
                <p className="mb-4 text-muted-foreground italic">"{t.quote}"</p>
                <div className="flex items-center gap-3">
                  <img src={t.image} alt={t.name} className="h-10 w-10 rounded-full object-cover" loading="lazy" />
                  <div>
                    <p className="font-semibold">{t.name}</p>
                    <p className="text-xs text-muted-foreground">{t.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>

    <section id="faq" className="bg-card py-20">
      <div className="container mx-auto max-w-3xl px-4">
        <div className="mb-12 text-center">
          <h2 className="mb-4 font-heading text-3xl font-bold md:text-4xl">Frequently Asked Questions</h2>
        </div>
        <Accordion type="single" collapsible>
          {faqs.map((faq, i) => (
            <AccordionItem key={i} value={`faq-${i}`}>
              <AccordionTrigger className="text-left">{faq.question}</AccordionTrigger>
              <AccordionContent>{faq.answer}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>

    <section className="py-20">
      <div className="container mx-auto px-4 text-center">
        <h2 className="mb-4 font-heading text-3xl font-bold md:text-4xl">Ready to Taste Home?</h2>
        <p className="mb-8 text-muted-foreground">Join thousands of happy customers enjoying fresh, home-cooked meals daily.</p>
        <div className="flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Link to="/signup"><Button size="lg" className="gap-2 px-8">Get Started <ArrowRight size={18} /></Button></Link>
          <Link to="/chef/onboarding"><Button variant="outline" size="lg" className="px-8">Start Cooking & Earning</Button></Link>
        </div>
      </div>
    </section>

    <Footer />
  </div>
);

export default Landing;
