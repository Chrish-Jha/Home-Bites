import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

const OrderSuccess = () => (
  <div className="flex min-h-screen items-center justify-center bg-background px-4">
    <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ duration: 0.5 }}>
      <Card className="w-full max-w-md text-center">
        <CardContent className="p-8">
          <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.2, type: "spring" }}>
            <CheckCircle2 className="mx-auto mb-4 h-20 w-20 text-success" />
          </motion.div>
          <h1 className="mb-2 font-heading text-2xl font-bold">Order Placed! 🎉</h1>
          <p className="mb-2 text-muted-foreground">Your order has been placed successfully.</p>
          <p className="mb-6 text-sm text-muted-foreground">Order ID: <span className="font-mono font-semibold">ORD-{Math.random().toString(36).substr(2, 6).toUpperCase()}</span></p>
          <div className="flex flex-col gap-3">
            <Link to="/order/ORD-002"><Button className="w-full">Track Order</Button></Link>
            <Link to="/home"><Button variant="outline" className="w-full">Continue Browsing</Button></Link>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  </div>
);

export default OrderSuccess;
