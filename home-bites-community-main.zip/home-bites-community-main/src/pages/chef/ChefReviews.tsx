import { Navbar } from "@/components/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { RatingStars } from "@/components/RatingStars";
import { reviews } from "@/data/mockData";

const ChefReviews = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-6 font-heading text-2xl font-bold">Customer Reviews</h1>
      <div className="mb-6 flex items-center gap-4">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
          <span className="font-heading text-2xl font-bold text-primary">4.8</span>
        </div>
        <div>
          <RatingStars rating={4.8} />
          <p className="text-sm text-muted-foreground">Based on 234 reviews</p>
        </div>
      </div>
      <div className="space-y-4">
        {reviews.map((r) => (
          <Card key={r.id}>
            <CardContent className="p-4">
              <div className="mb-2 flex items-center justify-between">
                <span className="font-semibold">{r.customerName}</span>
                <RatingStars rating={r.rating} size={14} />
              </div>
              <p className="mb-2 text-sm text-muted-foreground">{r.comment}</p>
              <p className="text-xs text-muted-foreground">{r.dishName} • {r.date}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  </div>
);

export default ChefReviews;
