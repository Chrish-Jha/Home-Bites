import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Link } from "react-router-dom";
import { ChevronRight, ChevronLeft, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { BrandLogo } from "@/components/BrandLogo";

const steps = ["Personal Info", "Kitchen Details", "Menu Setup", "Done"];

const ChefOnboarding = () => {
  const [step, setStep] = useState(0);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 py-8">
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center">
          <Link to="/" className="mb-4 flex items-center justify-center gap-2">
            <BrandLogo size="lg" />
          </Link>
          <CardTitle className="font-heading text-2xl">Become a Home Maker</CardTitle>
          <CardDescription>Join our community of women entrepreneurs</CardDescription>
          <div className="mt-4 flex justify-center gap-2">
            {steps.map((s, i) => (
              <div key={s} className={`h-2 w-12 rounded-full transition-all ${i <= step ? "bg-primary" : "bg-muted"}`} />
            ))}
          </div>
          <p className="mt-2 text-xs text-muted-foreground">Step {step + 1} of {steps.length}: {steps[step]}</p>
        </CardHeader>
        <CardContent>
          <AnimatePresence mode="wait">
            <motion.div key={step} initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} transition={{ duration: 0.2 }}>
              {step === 0 && (
                <div className="space-y-4">
                  <div className="space-y-2"><Label>Full Name</Label><Input placeholder="Your name" /></div>
                  <div className="space-y-2"><Label>Email</Label><Input type="email" placeholder="you@example.com" /></div>
                  <div className="space-y-2"><Label>Phone</Label><Input type="tel" placeholder="+91 98765 43210" /></div>
                  <div className="space-y-2"><Label>City</Label><Input placeholder="Your city" /></div>
                </div>
              )}
              {step === 1 && (
                <div className="space-y-4">
                  <div className="space-y-2"><Label>Kitchen Name</Label><Input placeholder="e.g. Lakshmi's Kitchen" /></div>
                  <div className="space-y-2"><Label>Food Category</Label><Input placeholder="e.g. South Indian, Biryani" /></div>
                  <div className="space-y-2"><Label>Short Bio</Label><Textarea placeholder="Tell customers about your cooking journey..." rows={3} /></div>
                  <div className="space-y-2"><Label>Delivery Range (km)</Label><Input type="number" placeholder="5" /></div>
                  <div className="space-y-2"><Label>FSSAI License (Optional)</Label><Input placeholder="License number" /></div>
                </div>
              )}
              {step === 2 && (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground">You can add your menu items after registration. For now, tell us about your signature dishes.</p>
                  <div className="space-y-2"><Label>Signature Dish 1</Label><Input placeholder="e.g. Hyderabadi Biryani" /></div>
                  <div className="space-y-2"><Label>Signature Dish 2</Label><Input placeholder="e.g. Masala Dosa" /></div>
                  <div className="space-y-2"><Label>Average Price Range</Label><Input placeholder="e.g. Rs.50 - Rs.200" /></div>
                </div>
              )}
              {step === 3 && (
                <div className="py-6 text-center">
                  <CheckCircle2 className="mx-auto mb-4 h-16 w-16 text-success" />
                  <h3 className="mb-2 font-heading text-xl font-bold">Application Submitted!</h3>
                  <p className="mb-4 text-muted-foreground">Our team will review your application and get back within 24-48 hours.</p>
                  <p className="text-sm text-muted-foreground">Meanwhile, you can explore the platform and prepare your menu items.</p>
                </div>
              )}
            </motion.div>
          </AnimatePresence>

          <div className="mt-6 flex justify-between">
            {step > 0 && step < 3 && (
              <Button variant="outline" onClick={() => setStep(step - 1)} className="gap-1">
                <ChevronLeft size={16} /> Back
              </Button>
            )}
            {step < 2 && (
              <Button onClick={() => setStep(step + 1)} className="ml-auto gap-1">
                Next <ChevronRight size={16} />
              </Button>
            )}
            {step === 2 && (
              <Button onClick={() => setStep(3)} className="ml-auto">Submit Application</Button>
            )}
            {step === 3 && (
              <Link to="/chef/dashboard" className="mx-auto">
                <Button>Go to Dashboard</Button>
              </Link>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ChefOnboarding;
