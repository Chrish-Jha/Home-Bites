import { Navbar } from "@/components/Navbar";
import { DashboardCard } from "@/components/DashboardCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DollarSign, TrendingUp, Calendar, Wallet } from "lucide-react";

const earningsData = [
  { period: "Today", amount: "₹1,240", orders: 8 },
  { period: "This Week", amount: "₹8,650", orders: 45 },
  { period: "This Month", amount: "₹32,400", orders: 178 },
  { period: "Last Month", amount: "₹28,900", orders: 156 },
];

const ChefEarnings = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="container mx-auto px-4 py-8">
      <h1 className="mb-8 font-heading text-2xl font-bold">Earnings Summary</h1>

      <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <DashboardCard title="Total Earnings" value="₹1,24,500" icon={DollarSign} trend="+15% vs last month" />
        <DashboardCard title="This Month" value="₹32,400" icon={Calendar} description="178 orders" />
        <DashboardCard title="Avg Order Value" value="₹182" icon={TrendingUp} />
        <DashboardCard title="Pending Payout" value="₹4,200" icon={Wallet} description="Next payout: Friday" />
      </div>

      <Card>
        <CardHeader><CardTitle className="font-heading">Earnings Breakdown</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-3">
            {earningsData.map((e) => (
              <div key={e.period} className="flex items-center justify-between rounded-lg border p-4">
                <div>
                  <p className="font-semibold">{e.period}</p>
                  <p className="text-sm text-muted-foreground">{e.orders} orders</p>
                </div>
                <span className="font-heading text-lg font-bold text-primary">{e.amount}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  </div>
);

export default ChefEarnings;
