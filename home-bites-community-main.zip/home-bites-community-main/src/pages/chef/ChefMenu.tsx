import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { dishes } from "@/data/mockData";
import { Plus, Pencil, Trash2 } from "lucide-react";

const ChefMenu = () => {
  const chefDishes = dishes.filter((d) => d.chefId === "chef-1");
  const [dialogOpen, setDialogOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6 flex items-center justify-between">
          <h1 className="font-heading text-2xl font-bold">Menu Management</h1>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2"><Plus size={16} /> Add Dish</Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle className="font-heading">Add New Dish</DialogTitle>
              </DialogHeader>
              <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); setDialogOpen(false); }}>
                <div className="space-y-2"><Label>Dish Name</Label><Input placeholder="e.g. Masala Dosa" /></div>
                <div className="space-y-2"><Label>Description</Label><Textarea placeholder="Describe your dish..." rows={3} /></div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2"><Label>Price (₹)</Label><Input type="number" placeholder="80" /></div>
                  <div className="space-y-2"><Label>Prep Time</Label><Input placeholder="e.g. 20 min" /></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2"><Label>Category</Label><Input placeholder="e.g. South Indian" /></div>
                  <div className="flex items-center gap-2 pt-6"><Switch defaultChecked /><Label>Vegetarian</Label></div>
                </div>
                <div className="space-y-2"><Label>Image URL</Label><Input placeholder="https://..." /></div>
                <Button type="submit" className="w-full">Add Dish</Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="space-y-4">
          {chefDishes.map((dish) => (
            <Card key={dish.id}>
              <CardContent className="flex items-center gap-4 p-4">
                <img src={dish.image} alt={dish.name} className="h-20 w-20 rounded-lg object-cover" />
                <div className="min-w-0 flex-1">
                  <div className="mb-1 flex items-center gap-2">
                    <h3 className="font-semibold">{dish.name}</h3>
                    <Badge variant={dish.isVeg ? "secondary" : "destructive"} className="text-xs">
                      {dish.isVeg ? "Veg" : "Non-Veg"}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{dish.category} • {dish.prepTime}</p>
                  <p className="font-heading font-bold text-primary">₹{dish.price}</p>
                </div>
                <div className="flex items-center gap-3">
                  <Switch defaultChecked={dish.available} />
                  <Button variant="ghost" size="icon"><Pencil size={16} /></Button>
                  <Button variant="ghost" size="icon" className="text-destructive"><Trash2 size={16} /></Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ChefMenu;
