import { Navbar } from "@/components/Navbar";
import { DashboardCard } from "@/components/DashboardCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ShoppingBag, DollarSign, Clock, TrendingUp, Plus, List } from "lucide-react";
import { Link } from "react-router-dom";
import { sampleOrders } from "@/data/mockData";

const ChefDashboard = () => {
  const pendingOrders = sampleOrders.filter((o) => o.status === "placed" || o.status === "accepted");

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="font-heading text-2xl font-bold">Welcome, Lakshmi! 👩‍🍳</h1>
            <p className="text-muted-foreground">Here's how your kitchen is doing today</p>
          </div>
          <div className="flex gap-3">
            <Link to="/chef/menu"><Button variant="outline" className="gap-2"><Plus size={16} /> Add Dish</Button></Link>
            <Link to="/chef/orders"><Button className="gap-2"><List size={16} /> View Orders</Button></Link>
          </div>
        </div>

        <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <DashboardCard title="Today's Orders" value={8} icon={ShoppingBag} trend="+12% from yesterday" />
          <DashboardCard title="Total Earnings" value="₹12,450" icon={DollarSign} trend="+8% this week" />
          <DashboardCard title="Pending Orders" value={pendingOrders.length} icon={Clock} description="Need your attention" />
          <DashboardCard title="Top Dish" value="Masala Dosa" icon={TrendingUp} description="32 orders this week" />
        </div>

        {/* Recent Orders */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="font-heading">Recent Orders</CardTitle>
              <Link to="/chef/orders"><Button variant="link" size="sm">View All</Button></Link>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {sampleOrders.slice(0, 4).map((order) => (
                <div key={order.id} className="flex items-center justify-between rounded-lg border p-4">
                  <div>
                    <p className="font-semibold">{order.id}</p>
                    <p className="text-sm text-muted-foreground">{order.customerName} • {order.items.length} item(s)</p>
                  </div>
                  <div className="text-right">
                    <p className="font-heading font-bold">₹{order.total}</p>
                    <p className="text-xs capitalize text-muted-foreground">{order.status.replace("_", " ")}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ChefDashboard;
