import { Navbar } from "@/components/Navbar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { sampleOrders } from "@/data/mockData";
import { useState } from "react";

const statusColors: Record<string, string> = {
  placed: "bg-accent text-accent-foreground",
  accepted: "bg-primary/20 text-primary",
  preparing: "bg-primary/40 text-foreground",
  out_for_delivery: "bg-primary text-primary-foreground",
  delivered: "bg-success text-success-foreground",
};

const ChefOrders = () => {
  const [filter, setFilter] = useState("all");
  const filtered = filter === "all" ? sampleOrders : sampleOrders.filter((o) => o.status === filter);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          <h1 className="font-heading text-2xl font-bold">Orders</h1>
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-48"><SelectValue placeholder="Filter by status" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Orders</SelectItem>
              <SelectItem value="placed">Placed</SelectItem>
              <SelectItem value="accepted">Accepted</SelectItem>
              <SelectItem value="preparing">Preparing</SelectItem>
              <SelectItem value="out_for_delivery">Out for Delivery</SelectItem>
              <SelectItem value="delivered">Delivered</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-4">
          {filtered.map((order) => (
            <Card key={order.id}>
              <CardContent className="p-4">
                <div className="mb-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-center gap-3">
                    <span className="font-heading font-semibold">{order.id}</span>
                    <Badge className={statusColors[order.status]}>{order.status.replace("_", " ")}</Badge>
                  </div>
                  <span className="text-sm text-muted-foreground">{order.date}</span>
                </div>
                <p className="mb-1 text-sm"><strong>Customer:</strong> {order.customerName}</p>
                <p className="mb-1 text-sm"><strong>Address:</strong> {order.address}</p>
                <p className="mb-3 text-sm text-muted-foreground">{order.items.map((i) => `${i.name} ×${i.quantity}`).join(", ")}</p>
                <div className="flex items-center justify-between">
                  <span className="font-heading text-lg font-bold">₹{order.total}</span>
                  <div className="flex gap-2">
                    {order.status === "placed" && (
                      <>
                        <Button size="sm" variant="outline" className="text-destructive">Reject</Button>
                        <Button size="sm">Accept</Button>
                      </>
                    )}
                    {order.status === "accepted" && <Button size="sm">Start Preparing</Button>}
                    {order.status === "preparing" && <Button size="sm">Ready for Pickup</Button>}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ChefOrders;
