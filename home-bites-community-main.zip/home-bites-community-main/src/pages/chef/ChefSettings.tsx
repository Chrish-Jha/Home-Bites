import { Navbar } from "@/components/Navbar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const ChefSettings = () => (
  <div className="min-h-screen bg-background">
    <Navbar />
    <div className="container mx-auto max-w-2xl px-4 py-8">
      <h1 className="mb-6 font-heading text-2xl font-bold">Profile Settings</h1>

      <Card className="mb-6">
        <CardHeader><CardTitle className="font-heading">Kitchen Details</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2"><Label>Full Name</Label><Input defaultValue="Lakshmi Devi" /></div>
            <div className="space-y-2"><Label>Kitchen Name</Label><Input defaultValue="Lakshmi's Kitchen" /></div>
            <div className="space-y-2"><Label>Phone</Label><Input defaultValue="+91 98765 43210" /></div>
            <div className="space-y-2"><Label>City</Label><Input defaultValue="Hyderabad" /></div>
            <div className="space-y-2"><Label>Delivery Range</Label><Input defaultValue="5 km" /></div>
            <div className="space-y-2"><Label>Speciality</Label><Input defaultValue="South Indian" /></div>
          </div>
          <div className="space-y-2"><Label>Bio</Label><Textarea defaultValue="A passionate home cook with 15 years of experience..." rows={3} /></div>
          <div className="space-y-2"><Label>FSSAI License</Label><Input placeholder="License number" /></div>
          <Button>Save Changes</Button>
        </CardContent>
      </Card>
    </div>
  </div>
);

export default ChefSettings;
