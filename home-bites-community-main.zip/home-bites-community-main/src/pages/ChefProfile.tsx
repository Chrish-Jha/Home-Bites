import { useParams } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { FoodCard } from "@/components/FoodCard";
import { RatingStars } from "@/components/RatingStars";
import { Badge } from "@/components/ui/badge";
import { chefs, dishes, reviews } from "@/data/mockData";
import { MapPin, ShieldCheck, Clock, Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const ChefProfile = () => {
  const { id } = useParams();
  const chef = chefs.find((c) => c.id === id) || chefs[0];
  const chefDishes = dishes.filter((d) => d.chefId === chef.id);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        {/* Chef Header */}
        <Card className="mb-8">
          <CardContent className="flex flex-col gap-6 p-6 md:flex-row md:items-center">
            <img src={chef.image} alt={chef.name} className="h-32 w-32 rounded-full object-cover ring-4 ring-primary/20" />
            <div className="flex-1">
              <div className="mb-2 flex flex-wrap items-center gap-2">
                <h1 className="font-heading text-2xl font-bold">{chef.kitchenName}</h1>
                {chef.verified && (
                  <Badge className="gap-1 bg-success text-success-foreground">
                    <ShieldCheck size={14} /> Verified Kitchen
                  </Badge>
                )}
              </div>
              <p className="mb-2 text-muted-foreground">{chef.name}</p>
              <p className="mb-4 text-sm text-muted-foreground">{chef.bio}</p>
              <div className="flex flex-wrap gap-4 text-sm">
                <span className="flex items-center gap-1"><MapPin size={14} /> {chef.city}</span>
                <span className="flex items-center gap-1"><Star size={14} className="text-accent" /> {chef.rating} ({chef.reviewCount} reviews)</span>
                <span className="flex items-center gap-1"><Clock size={14} /> Delivery: {chef.deliveryRange}</span>
                <span>{chef.totalOrders}+ orders served</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Menu */}
        <h2 className="mb-6 font-heading text-xl font-bold">Menu ({chefDishes.length} items)</h2>
        <div className="mb-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {chefDishes.map((dish) => (
            <FoodCard key={dish.id} dish={dish} />
          ))}
        </div>

        {/* Reviews */}
        <h2 className="mb-6 font-heading text-xl font-bold">Reviews</h2>
        <div className="grid gap-4 md:grid-cols-2">
          {reviews.slice(0, 4).map((review) => (
            <Card key={review.id}>
              <CardContent className="p-4">
                <div className="mb-2 flex items-center justify-between">
                  <span className="font-semibold">{review.customerName}</span>
                  <RatingStars rating={review.rating} size={14} />
                </div>
                <p className="mb-2 text-sm text-muted-foreground">{review.comment}</p>
                <p className="text-xs text-muted-foreground">{review.dishName} • {review.date}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ChefProfile;
