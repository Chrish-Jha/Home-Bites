import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { FoodCard } from "@/components/FoodCard";
import { ChefCard } from "@/components/ChefCard";
import { CategoryChips } from "@/components/CategoryChips";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { chefs, dishes } from "@/data/mockData";
import { Search, MapPin } from "lucide-react";
import { Link } from "react-router-dom";

const CustomerHome = () => {
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filteredDishes = dishes.filter((d) => {
    const matchCategory = selectedCategory === "all" || d.category === selectedCategory;
    const matchSearch = d.name.toLowerCase().includes(searchQuery.toLowerCase()) || d.chefName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCategory && matchSearch;
  });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero */}
      <section className="bg-card px-4 py-8">
        <div className="container mx-auto">
          <div className="mb-4 flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin size={16} className="text-primary" />
            <span>Delivering to: <strong className="text-foreground">Hyderabad, Banjara Hills</strong></span>
            <Button variant="link" size="sm" className="h-auto p-0 text-primary">Change</Button>
          </div>
          <h1 className="mb-4 font-heading text-2xl font-bold md:text-3xl">What are you craving today?</h1>
          <div className="relative max-w-xl">
            <Search className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
            <Input
              placeholder="Search dishes, cuisines, or home makers..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-6">
        {/* Categories */}
        <div className="mb-8">
          <h2 className="mb-4 font-heading text-lg font-semibold">Categories</h2>
          <CategoryChips selected={selectedCategory} onSelect={setSelectedCategory} />
        </div>

        {/* Featured Chefs */}
        <section className="mb-10">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-heading text-lg font-semibold">Featured Home Makers</h2>
            <Link to="/search"><Button variant="link" size="sm">View All</Button></Link>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {chefs.slice(0, 3).map((chef) => (
              <ChefCard key={chef.id} chef={chef} />
            ))}
          </div>
        </section>

        {/* Popular Dishes */}
        <section>
          <h2 className="mb-4 font-heading text-lg font-semibold">
            {selectedCategory === "all" ? "Popular Dishes" : `${selectedCategory.replace("-", " ")} Dishes`}
          </h2>
          {filteredDishes.length === 0 ? (
            <div className="py-16 text-center text-muted-foreground">
              <p className="text-4xl mb-4">🍽️</p>
              <p>No dishes found. Try a different search or category.</p>
            </div>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {filteredDishes.map((dish) => (
                <FoodCard key={dish.id} dish={dish} />
              ))}
            </div>
          )}
        </section>
      </div>

      <Footer />
    </div>
  );
};

export default CustomerHome;
