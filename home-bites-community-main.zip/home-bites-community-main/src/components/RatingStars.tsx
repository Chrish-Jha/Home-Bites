import { Star } from "lucide-react";

export const RatingStars = ({ rating, size = 16 }: { rating: number; size?: number }) => (
  <div className="flex items-center gap-0.5">
    {[1, 2, 3, 4, 5].map((star) => (
      <Star
        key={star}
        className={star <= Math.round(rating) ? "fill-accent text-accent" : "text-border"}
        size={size}
      />
    ))}
  </div>
);
