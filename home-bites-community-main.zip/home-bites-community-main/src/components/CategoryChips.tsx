import { Badge } from "@/components/ui/badge";
import { categories } from "@/data/mockData";

export const CategoryChips = ({ selected, onSelect }: { selected: string; onSelect: (id: string) => void }) => (
  <div className="flex flex-wrap gap-2">
    <Badge
      variant={selected === "all" ? "default" : "secondary"}
      className="cursor-pointer px-4 py-2 text-sm transition-all hover:scale-105"
      onClick={() => onSelect("all")}
    >
      🍴 All
    </Badge>
    {categories.map((cat) => (
      <Badge
        key={cat.id}
        variant={selected === cat.id ? "default" : "secondary"}
        className="cursor-pointer px-4 py-2 text-sm transition-all hover:scale-105"
        onClick={() => onSelect(cat.id)}
      >
        {cat.emoji} {cat.name}
      </Badge>
    ))}
  </div>
);
