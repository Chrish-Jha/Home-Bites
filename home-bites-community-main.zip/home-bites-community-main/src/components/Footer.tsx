import { Link } from "react-router-dom";
import { BrandLogo } from "@/components/BrandLogo";

export const Footer = () => (
  <footer className="border-t bg-card">
    <div className="container mx-auto px-4 py-12">
      <div className="grid gap-8 md:grid-cols-4">
        <div>
          <div className="mb-4 flex items-center gap-2">
            <BrandLogo size="md" />
          </div>
          <p className="text-sm text-muted-foreground">
            Empowering women through home-cooked food delivery. Fresh, hygienic, and made with love.
          </p>
        </div>
        <div>
          <h4 className="mb-4 font-heading font-semibold">Quick Links</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/home" className="hover:text-primary">Browse Food</Link></li>
            <li><Link to="/search" className="hover:text-primary">Search</Link></li>
            <li><Link to="/orders" className="hover:text-primary">My Orders</Link></li>
            <li><Link to="/profile" className="hover:text-primary">Profile</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-4 font-heading font-semibold">For Home Makers</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><Link to="/chef/onboarding" className="hover:text-primary">Join as a Chef</Link></li>
            <li><Link to="/chef/dashboard" className="hover:text-primary">Chef Dashboard</Link></li>
            <li><Link to="#" className="hover:text-primary">Success Stories</Link></li>
            <li><Link to="#" className="hover:text-primary">Support</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-4 font-heading font-semibold">Contact</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>hello@homebites.in</li>
            <li>+91 98765 43210</li>
            <li>Hyderabad, India</li>
          </ul>
        </div>
      </div>
      <div className="mt-8 border-t pt-6 text-center text-sm text-muted-foreground">
        © 2024 Home Bites. Made with love for women empowerment.
      </div>
    </div>
  </footer>
);
