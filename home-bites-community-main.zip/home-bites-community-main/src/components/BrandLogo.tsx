type BrandLogoProps = {
  className?: string;
  size?: "sm" | "md" | "lg";
};

const sizeClasses: Record<NonNullable<BrandLogoProps["size"]>, string> = {
  sm: "h-10 w-10",
  md: "h-12 w-12",
  lg: "h-16 w-16",
};

export const BrandLogo = ({ className = "", size = "md" }: BrandLogoProps) => (
  <div className={`flex items-center gap-3 ${className}`.trim()}>
    <svg
      viewBox="0 0 120 120"
      className={`${sizeClasses[size]} shrink-0`}
      role="img"
      aria-label="Home Bites logo"
    >
      <circle cx="60" cy="60" r="54" fill="#fbf7ef" stroke="#d8c0a1" strokeWidth="2.5" />
      <circle
        cx="60"
        cy="60"
        r="48"
        fill="none"
        stroke="#c69b70"
        strokeWidth="2"
        strokeDasharray="4 6"
        strokeLinecap="round"
      />
      <g transform="translate(12 14)">
        <g fill="#c8742f" stroke="#9c5820" strokeWidth="1.2" strokeLinejoin="round" strokeLinecap="round">
          <rect x="4" y="33" width="11" height="32" rx="4" transform="rotate(-28 9.5 49)" />
          <rect x="78" y="31" width="11" height="34" rx="4" transform="rotate(18 83.5 48)" />
          <path d="M31 20c3 0 6 4 6 8s-3 8-6 8-6-4-6-8 3-8 6-8Zm-1 16h2v27h-2z" />
        </g>
        <g fill="none" stroke="#6f6a67" strokeWidth="1.8" strokeLinecap="round">
          <path d="M90 37c4 4 8 13 8 22" />
          <path d="M94 35c6 6 12 18 11 28" />
          <path d="M98 33c8 8 15 19 15 30" />
          <path d="M86 41c5 4 9 10 10 18" />
          <path d="M102 32c10 8 17 20 18 31" />
          <path d="M96 62l-7 10" />
        </g>
        <g transform="translate(33 10)">
          <path
            d="M8 22c-4 0-8-3-8-7 0-5 4-8 9-8 1-5 7-7 13-5 4-4 10-5 15-2 5-1 10 2 12 6 5 1 8 5 8 10 0 4-3 6-7 6H8Z"
            fill="#f4dedd"
            stroke="#c9a09a"
            strokeWidth="1.2"
          />
          <path d="M22 14v10M32 12v12M42 14v10" stroke="#7d615c" strokeWidth="1.6" strokeLinecap="round" />
          <path
            d="M16 26h28l-2 11c-1 4-5 7-10 7h-8c-5 0-9-3-10-7l-2-11Z"
            fill="#f5dfdd"
            stroke="#c9a09a"
            strokeWidth="1.2"
          />
          <path d="M18 31h24" stroke="#a47f77" strokeWidth="1.2" />
        </g>
        <g transform="translate(8 48)">
          <path
            d="M7 8c4-6 11-8 19-8h40c8 0 16 2 20 8 6 0 10 3 10 7s-3 7-8 8c-3 10-14 17-28 17H29C14 40 3 33 0 23-5 22-8 18-8 14c0-4 5-6 15-6Z"
            fill="#fbf6ee"
            stroke="#b8aa9a"
            strokeWidth="1.5"
          />
          <path d="M88 25c7 1 13 6 16 12" fill="none" stroke="#b8aa9a" strokeWidth="1.5" strokeLinecap="round" />
          <path d="M84 32c6 4 10 8 13 13" fill="none" stroke="#b8aa9a" strokeWidth="1.5" strokeLinecap="round" />
          <text
            x="48"
            y="23"
            textAnchor="middle"
            fontSize="10"
            fontWeight="700"
            fontStyle="italic"
            letterSpacing="0.8"
            fill="#111111"
          >
            HOME BITES
          </text>
        </g>
      </g>
    </svg>
    <span className="sr-only">Home Bites</span>
  </div>
);
