import { Link, useLocation } from "react-router-dom";
import { ShoppingCart, Menu, X, User } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/contexts/CartContext";
import { Badge } from "@/components/ui/badge";
import { BrandLogo } from "@/components/BrandLogo";

export const Navbar = () => {
  const [mobileOpen, setMobileOpen] = useState(false);
  const { totalItems } = useCart();
  const location = useLocation();

  const isChef = location.pathname.startsWith("/chef");
  const isAdmin = location.pathname.startsWith("/admin");

  return (
    <nav className="sticky top-0 z-50 border-b bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2">
          <BrandLogo size="sm" />
        </Link>

        <div className="hidden items-center gap-6 md:flex">
          {!isChef && !isAdmin && (
            <>
              <Link to="/home" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                Browse
              </Link>
              <Link to="/search" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                Search
              </Link>
              <Link to="/orders" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                My Orders
              </Link>
            </>
          )}
          {isChef && (
            <>
              <Link to="/chef/dashboard" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                Dashboard
              </Link>
              <Link to="/chef/menu" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                Menu
              </Link>
              <Link to="/chef/orders" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                Orders
              </Link>
              <Link to="/chef/earnings" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                Earnings
              </Link>
            </>
          )}
          {isAdmin && (
            <>
              <Link to="/admin" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                Dashboard
              </Link>
              <Link to="/admin/approvals" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                Approvals
              </Link>
              <Link to="/admin/users" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                Users
              </Link>
              <Link to="/admin/orders" className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground">
                Orders
              </Link>
            </>
          )}
        </div>

        <div className="flex items-center gap-3">
          {!isChef && !isAdmin && (
            <Link to="/cart" className="relative">
              <Button variant="ghost" size="icon">
                <ShoppingCart className="h-5 w-5" />
              </Button>
              {totalItems > 0 && (
                <Badge className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full p-0 text-xs">
                  {totalItems}
                </Badge>
              )}
            </Link>
          )}
          <Link to="/profile">
            <Button variant="ghost" size="icon">
              <User className="h-5 w-5" />
            </Button>
          </Link>
          <button className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="border-t bg-card px-4 pb-4 pt-2 md:hidden">
          <div className="flex flex-col gap-2">
            {!isChef && !isAdmin && (
              <>
                <Link to="/home" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Browse Food
                </Link>
                <Link to="/search" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Search
                </Link>
                <Link to="/orders" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  My Orders
                </Link>
                <Link to="/profile" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Profile
                </Link>
              </>
            )}
            {isChef && (
              <>
                <Link to="/chef/dashboard" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Dashboard
                </Link>
                <Link to="/chef/menu" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Menu
                </Link>
                <Link to="/chef/orders" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Orders
                </Link>
                <Link to="/chef/earnings" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Earnings
                </Link>
                <Link to="/chef/reviews" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Reviews
                </Link>
                <Link to="/chef/settings" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Settings
                </Link>
              </>
            )}
            {isAdmin && (
              <>
                <Link to="/admin" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Dashboard
                </Link>
                <Link to="/admin/approvals" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Approvals
                </Link>
                <Link to="/admin/users" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Users
                </Link>
                <Link to="/admin/orders" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
                  Orders
                </Link>
              </>
            )}
            <div className="my-2 border-t" />
            <Link to="/login" onClick={() => setMobileOpen(false)} className="rounded-md px-3 py-2 text-sm font-medium hover:bg-secondary">
              Login
            </Link>
            <Link
              to="/chef/onboarding"
              onClick={() => setMobileOpen(false)}
              className="rounded-md px-3 py-2 text-sm font-medium text-primary hover:bg-secondary"
            >
              Become a Home Maker
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
};
