import { CheckCircle2, Circle, Clock, Package, Truck } from "lucide-react";

const steps = [
  { key: "placed", label: "Order Placed", icon: Clock },
  { key: "accepted", label: "Accepted", icon: CheckCircle2 },
  { key: "preparing", label: "Preparing", icon: Package },
  { key: "out_for_delivery", label: "Out for Delivery", icon: Truck },
  { key: "delivered", label: "Delivered", icon: CheckCircle2 },
];

const statusIndex = { placed: 0, accepted: 1, preparing: 2, out_for_delivery: 3, delivered: 4 };

export const OrderStatusStepper = ({ status }: { status: string }) => {
  const currentIndex = statusIndex[status as keyof typeof statusIndex] ?? 0;

  return (
    <div className="flex items-center justify-between">
      {steps.map((step, index) => {
        const Icon = step.icon;
        const isCompleted = index <= currentIndex;
        const isCurrent = index === currentIndex;

        return (
          <div key={step.key} className="flex flex-1 items-center">
            <div className="flex flex-col items-center gap-1">
              <div className={`flex h-10 w-10 items-center justify-center rounded-full transition-all ${
                isCompleted ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"
              } ${isCurrent ? "ring-4 ring-primary/20" : ""}`}>
                <Icon size={20} />
              </div>
              <span className={`text-center text-xs ${isCompleted ? "font-semibold text-foreground" : "text-muted-foreground"}`}>
                {step.label}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div className={`mx-1 h-1 flex-1 rounded-full ${index < currentIndex ? "bg-primary" : "bg-muted"}`} />
            )}
          </div>
        );
      })}
    </div>
  );
};
