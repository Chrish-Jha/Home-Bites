import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Chef } from "@/data/mockData";
import { RatingStars } from "./RatingStars";
import { Link } from "react-router-dom";
import { MapPin, ShieldCheck } from "lucide-react";

export const ChefCard = ({ chef }: { chef: Chef }) => (
  <Link to={`/chef/${chef.id}`}>
    <Card className="group overflow-hidden transition-all hover:shadow-lg active:scale-[0.98]">
      <CardContent className="flex gap-4 p-4">
        <img src={chef.image} alt={chef.name} className="h-20 w-20 rounded-full object-cover ring-2 ring-primary/20" loading="lazy" />
        <div className="min-w-0 flex-1">
          <div className="mb-1 flex items-center gap-2">
            <h3 className="truncate font-heading font-semibold">{chef.kitchenName}</h3>
            {chef.verified && (
              <Badge variant="secondary" className="shrink-0 gap-1 text-success">
                <ShieldCheck size={12} /> Verified
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground">{chef.name}</p>
          <div className="mt-1 flex items-center gap-1 text-sm">
            <RatingStars rating={chef.rating} size={12} />
            <span className="text-muted-foreground">({chef.reviewCount})</span>
          </div>
          <div className="mt-2 flex items-center gap-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><MapPin size={12} /> {chef.city}</span>
            <span>{chef.speciality}</span>
            <span>{chef.totalOrders}+ orders</span>
          </div>
        </div>
      </CardContent>
    </Card>
  </Link>
);
