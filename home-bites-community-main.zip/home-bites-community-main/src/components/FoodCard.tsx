import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Plus } from "lucide-react";
import { Dish } from "@/data/mockData";
import { RatingStars } from "./RatingStars";
import { useCart } from "@/contexts/CartContext";

export const FoodCard = ({ dish }: { dish: Dish }) => {
  const { addItem } = useCart();

  return (
    <Card className="group overflow-hidden transition-all hover:shadow-lg active:scale-[0.98]">
      <div className="relative aspect-[4/3] overflow-hidden">
        <img src={dish.image} alt={dish.name} className="h-full w-full object-cover transition-transform group-hover:scale-105" loading="lazy" />
        <Badge className={`absolute left-3 top-3 ${dish.isVeg ? "bg-success text-success-foreground" : "bg-destructive text-destructive-foreground"}`}>
          {dish.isVeg ? "🟢 Veg" : "🔴 Non-Veg"}
        </Badge>
        {!dish.available && (
          <div className="absolute inset-0 flex items-center justify-center bg-foreground/50">
            <span className="rounded-full bg-card px-4 py-2 font-semibold">Currently Unavailable</span>
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <div className="mb-2 flex items-start justify-between">
          <h3 className="font-heading font-semibold leading-tight">{dish.name}</h3>
          <span className="ml-2 whitespace-nowrap font-heading text-lg font-bold text-primary">₹{dish.price}</span>
        </div>
        <p className="mb-3 line-clamp-2 text-sm text-muted-foreground">{dish.description}</p>
        <div className="mb-3 flex items-center gap-3 text-sm text-muted-foreground">
          <span className="flex items-center gap-1"><Clock size={14} /> {dish.prepTime}</span>
          <div className="flex items-center gap-1">
            <RatingStars rating={dish.rating} size={12} />
            <span>{dish.rating}</span>
          </div>
        </div>
        <p className="mb-3 text-xs text-muted-foreground">by {dish.chefName}</p>
        <Button onClick={() => addItem(dish)} disabled={!dish.available} className="w-full" size="sm">
          <Plus size={16} /> Add to Cart
        </Button>
      </CardContent>
    </Card>
  );
};
